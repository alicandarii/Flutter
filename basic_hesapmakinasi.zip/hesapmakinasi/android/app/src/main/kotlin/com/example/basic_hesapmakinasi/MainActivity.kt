package com.example.basic_hesapmakinasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
